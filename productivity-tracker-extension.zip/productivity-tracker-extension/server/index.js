const express = require("express");
const cors = require("cors");
const app = express();
app.use(cors());
app.use(express.json());

let db = {};

app.post("/log", (req, res) => {
  const { url, duration } = req.body;
  const category = url.includes("leetcode") || url.includes("github") ? "productive" : "unproductive";
  db[category] = (db[category] || 0) + Math.floor(duration / 60000);
  res.sendStatus(200);
});

app.get("/summary", (req, res) => {
  res.json({ productive: db.productive || 0, unproductive: db.unproductive || 0 });
});

app.listen(3000, () => console.log("Backend running on http://localhost:3000"));
