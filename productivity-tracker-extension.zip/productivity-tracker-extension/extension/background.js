let activeTab = null;
let startTime = null;

chrome.tabs.onActivated.addListener(({ tabId }) => {
  chrome.tabs.get(tabId, (tab) => {
    logTime(tab.url);
    activeTab = tab.url;
    startTime = Date.now();
  });
});

function logTime(url) {
  if (activeTab && startTime) {
    const duration = Date.now() - startTime;
    fetch("http://localhost:3000/log", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url: activeTab, duration })
    });
  }
}
