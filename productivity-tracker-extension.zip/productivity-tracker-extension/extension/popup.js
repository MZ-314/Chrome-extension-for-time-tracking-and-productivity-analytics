fetch("http://localhost:3000/summary")
  .then(res => res.json())
  .then(data => {
    document.getElementById("stats").innerText =
      `Productive: ${data.productive} mins\nUnproductive: ${data.unproductive} mins`;
  });
